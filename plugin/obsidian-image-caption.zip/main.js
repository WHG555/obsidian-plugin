var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// src/main.ts
__export(exports, {
  default: () => ImageCaptionPlugin
});
var import_obsidian2 = __toModule(require("obsidian"));

// src/md_processor.ts
var import_obsidian = __toModule(require("obsidian"));
function captionObserver(plugin, ctx) {
  return new MutationObserver((mutations, observer) => {
    for (const mutation of mutations) {
      if (!mutation.target.matches("span.image-embed")) {
        continue;
      }
      let caption_text = mutation.target.getAttribute("alt");
      if (caption_text === mutation.target.getAttribute("src")) {
        continue;
      }
      if (mutation.target.querySelector(ImageCaptionPlugin.caption_selector)) {
        continue;
      }
      caption_text = parseCaptionText(caption_text, plugin.settings.delimeter);
      if (caption_text !== null) {
        const caption = addCaption(mutation.target, caption_text);
        ctx.addChild(caption);
      }
    }
    updateFigureIndices();
    plugin.removeObserver(observer);
  });
}
function parseCaptionText(text, delimeter) {
  if (delimeter.length === 0) {
    return text;
  }
  let start, end;
  if (delimeter.length == 1) {
    delimeter = delimeter[0];
    start = text.indexOf(delimeter);
    end = text.lastIndexOf(delimeter);
  } else if (delimeter.length === 2) {
    start = text.indexOf(delimeter[0]);
    end = text.lastIndexOf(delimeter[1]);
  } else {
    return null;
  }
  if (start === -1 || end === -1) {
    return null;
  }
  if (start === end) {
    return "";
  }
  const start_offset = delimeter[0].length;
  return text.slice(start + start_offset, end);
}
function addCaption(target, caption_text) {
  const caption = document.createElement(ImageCaptionPlugin.caption_tag);
  caption.addClass(ImageCaptionPlugin.caption_class);
  caption.innerText = caption_text;
  target.appendChild(caption);
  return new import_obsidian.MarkdownRenderChild(caption);
}
function updateFigureIndices() {
  document.querySelectorAll("div.workspace-leaf").forEach((container) => {
    let index = 1;
    container.querySelectorAll(ImageCaptionPlugin.caption_selector).forEach((el) => {
      el.dataset.imageCaptionIndex = index;
      index += 1;
    });
  });
}
function processImageCaption(plugin) {
  return function(el, ctx) {
    el.querySelectorAll("span.internal-embed").forEach((container) => {
      const observer = captionObserver(plugin, ctx);
      observer.observe(container, { attributes: true, attributesFilter: ["class"] });
      plugin.addObserver(observer);
    });
  };
}

// src/main.ts
var DEFAULT_SETTINGS = {
  css: "",
  label: "",
  delimeter: []
};
var _ImageCaptionPlugin = class extends import_obsidian2.Plugin {
  onload() {
    return __async(this, null, function* () {
      yield this.loadSettings();
      this.caption_observers = [];
      this.registerMarkdownPostProcessor(processImageCaption(this));
      this.addStylesheet();
      this.addSettingTab(new ImageCaptionSettingTab(this.app, this));
    });
  }
  onunload() {
    this.stylesheet.remove();
    this.clearObservers();
    this.removeCaptions();
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
  addObserver(observer) {
    this.caption_observers.push(observer);
  }
  removeObserver(observer) {
    observer.disconnect();
    const index = this.caption_observers.indexOf(observer);
    this.caption_observers.splice(index, 1);
  }
  clearObservers() {
    for (const observer of this.caption_observers) {
      observer.disconnect();
    }
    this.caption_observers = [];
  }
  addStylesheet() {
    this.stylesheet = document.createElement("style");
    this.stylesheet.setAttribute("type", "text/css");
    this.updateStylesheet();
    document.head.append(this.stylesheet);
  }
  updateStylesheet() {
    const css = this.settings.css ? `${_ImageCaptionPlugin.caption_selector} { ${this.settings.css} }` : "";
    let label = this.settings.label;
    if (label) {
      const number_pattern = /(^|[^\\])#/g;
      label = label.replace(number_pattern, "$1' attr(data-image-caption-index) '");
      label = label.replace("\\#", "#");
      label = `${_ImageCaptionPlugin.caption_selector}::before { content: '${label} ' }`;
    }
    this.stylesheet.innerText = `${css} ${label}`;
  }
  removeCaptions() {
    for (const caption of document.querySelectorAll(_ImageCaptionPlugin.caption_selector)) {
      caption.remove();
    }
  }
};
var ImageCaptionPlugin = _ImageCaptionPlugin;
ImageCaptionPlugin.caption_tag = "figcaption";
ImageCaptionPlugin.caption_class = "obsidian-image-caption";
ImageCaptionPlugin.caption_selector = `${_ImageCaptionPlugin.caption_tag}.${_ImageCaptionPlugin.caption_class}`;
var ImageCaptionSettingTab = class extends import_obsidian2.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    let { containerEl } = this;
    containerEl.empty();
    new import_obsidian2.Setting(containerEl).setName("Label").setDesc("Prepend this text before each caption.").addText((text) => text.setPlaceholder("Label").setValue(this.plugin.settings.label).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.label = value.trim();
      yield this.plugin.saveSettings();
      this.plugin.updateStylesheet();
    })));
    new import_obsidian2.Setting(containerEl).setName("CSS").setDesc("Custom CSS styling for captions.").addTextArea((text) => text.setPlaceholder("Enter your CSS").setValue(this.plugin.settings.css).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.css = value.trim();
      yield this.plugin.saveSettings();
      this.plugin.updateStylesheet();
    })));
    const delimeter = new import_obsidian2.Setting(containerEl).setName("Delimeter").setDesc("Identify the caption by surrounding it with the delimeter. Start and end delimeters mays be specified by separation with a comma (,).").setTooltip("If no delimeter is provided the entire alt text is taken to be the caption. If a single delimeter is specified it must indicate the start and end of the caption. If two delimeters are specified, by separation with a comma, the caption is taken to be the text between the start and end delimeters.");
    delimeter.addText((text) => text.setPlaceholder("Delimeter").setValue(this.plugin.settings.delimeter.join(", ")).onChange((value) => __async(this, null, function* () {
      let delimeters = value.split(",").map((d) => d.trim());
      if (delimeters.length > 2) {
        delimeter.controlEl.addClass("setting-error");
        return;
      }
      if (delimeters.length === 2 && delimeters.some((d) => !d)) {
        delimeter.controlEl.addClass("setting-error");
        return;
      }
      if (delimeters.length === 1 && delimeters[0] === "") {
        delimeters = [];
      }
      delimeter.controlEl.removeClass("setting-error");
      this.plugin.settings.delimeter = delimeters;
      yield this.plugin.saveSettings();
    })));
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4udHMiLCAic3JjL21kX3Byb2Nlc3Nvci50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHtcclxuXHRBcHAsXHJcblx0UGx1Z2luLFxyXG5cdFBsdWdpblNldHRpbmdUYWIsXHJcblx0U2V0dGluZ1xyXG59IGZyb20gJ29ic2lkaWFuJztcclxuXHJcbmltcG9ydCB7XHJcblx0Y2FwdGlvbk9ic2VydmVyLFxyXG5cdHByb2Nlc3NJbWFnZUNhcHRpb25cclxufSBmcm9tICcuL21kX3Byb2Nlc3Nvcic7XHJcblxyXG5cclxuaW50ZXJmYWNlIEltYWdlQ2FwdGlvblNldHRpbmdzIHtcclxuXHRjc3M6IHN0cmluZztcclxuXHRsYWJlbDogc3RyaW5nO1xyXG5cdGRlbGltZXRlcjogc3RyaW5nW107XHJcbn1cclxuXHJcbmNvbnN0IERFRkFVTFRfU0VUVElOR1M6IEltYWdlQ2FwdGlvblNldHRpbmdzID0ge1xyXG5cdGNzczogJycsXHJcblx0bGFiZWw6ICcnLFxyXG5cdGRlbGltZXRlcjogW11cclxufVxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEltYWdlQ2FwdGlvblBsdWdpbiBleHRlbmRzIFBsdWdpbiB7XHJcblx0c2V0dGluZ3M6IEltYWdlQ2FwdGlvblNldHRpbmdzO1xyXG5cclxuXHRzdGF0aWMgY2FwdGlvbl90YWc6IHN0cmluZyA9ICdmaWdjYXB0aW9uJztcclxuXHRzdGF0aWMgY2FwdGlvbl9jbGFzczogc3RyaW5nID0gJ29ic2lkaWFuLWltYWdlLWNhcHRpb24nO1xyXG5cdHN0YXRpYyBjYXB0aW9uX3NlbGVjdG9yOiBzdHJpbmcgPSBgJHtJbWFnZUNhcHRpb25QbHVnaW4uY2FwdGlvbl90YWd9LiR7SW1hZ2VDYXB0aW9uUGx1Z2luLmNhcHRpb25fY2xhc3N9YDtcclxuXHJcblxyXG5cdGFzeW5jIG9ubG9hZCgpIHtcclxuXHRcdGF3YWl0IHRoaXMubG9hZFNldHRpbmdzKCk7XHJcblxyXG5cdFx0dGhpcy5jYXB0aW9uX29ic2VydmVycyA9IFtdO1xyXG5cdFx0dGhpcy5yZWdpc3Rlck1hcmtkb3duUG9zdFByb2Nlc3NvciggcHJvY2Vzc0ltYWdlQ2FwdGlvbiggdGhpcyApICk7XHJcblxyXG5cdFx0dGhpcy5hZGRTdHlsZXNoZWV0KCk7XHJcblx0XHR0aGlzLmFkZFNldHRpbmdUYWIoIG5ldyBJbWFnZUNhcHRpb25TZXR0aW5nVGFiKCB0aGlzLmFwcCwgdGhpcyApICk7XHJcblx0fVxyXG5cclxuXHRvbnVubG9hZCgpIHtcclxuXHRcdHRoaXMuc3R5bGVzaGVldC5yZW1vdmUoKTtcclxuXHRcdHRoaXMuY2xlYXJPYnNlcnZlcnMoKTtcclxuXHRcdHRoaXMucmVtb3ZlQ2FwdGlvbnMoKTtcclxuXHR9XHJcblxyXG5cdGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcclxuXHRcdHRoaXMuc2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKCB7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpICk7XHJcblx0fVxyXG5cclxuXHRhc3luYyBzYXZlU2V0dGluZ3MoKSB7XHJcblx0XHRhd2FpdCB0aGlzLnNhdmVEYXRhKCB0aGlzLnNldHRpbmdzICk7XHJcblx0fVxyXG5cclxuXHRhZGRPYnNlcnZlciggb2JzZXJ2ZXI6IE11dGF0aW9uT2JzZXJ2ZXIgKSB7XHJcblx0XHR0aGlzLmNhcHRpb25fb2JzZXJ2ZXJzLnB1c2goIG9ic2VydmVyICk7XHJcblx0fVxyXG5cclxuXHRyZW1vdmVPYnNlcnZlciggb2JzZXJ2ZXI6IE11dGF0aW9uT2JzZXJ2ZXIgKSB7XHJcblx0XHRvYnNlcnZlci5kaXNjb25uZWN0KCk7XHJcblx0XHRjb25zdCBpbmRleCA9IHRoaXMuY2FwdGlvbl9vYnNlcnZlcnMuaW5kZXhPZiggb2JzZXJ2ZXIgKTtcclxuXHRcdHRoaXMuY2FwdGlvbl9vYnNlcnZlcnMuc3BsaWNlKCBpbmRleCwgMSApO1xyXG5cdH1cclxuXHJcblx0Y2xlYXJPYnNlcnZlcnMoKSB7XHJcblx0XHRmb3IgKCBjb25zdCBvYnNlcnZlciBvZiB0aGlzLmNhcHRpb25fb2JzZXJ2ZXJzICkge1xyXG5cdFx0XHRvYnNlcnZlci5kaXNjb25uZWN0KCk7XHJcblx0XHR9XHJcblxyXG5cdFx0dGhpcy5jYXB0aW9uX29ic2VydmVycyA9IFtdO1xyXG5cdH1cclxuXHJcblx0YWRkU3R5bGVzaGVldCgpIHtcclxuXHRcdHRoaXMuc3R5bGVzaGVldCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoICdzdHlsZScgKTtcclxuXHRcdHRoaXMuc3R5bGVzaGVldC5zZXRBdHRyaWJ1dGUoICd0eXBlJywgJ3RleHQvY3NzJyApO1xyXG5cdFx0dGhpcy51cGRhdGVTdHlsZXNoZWV0KCk7XHJcblx0XHRkb2N1bWVudC5oZWFkLmFwcGVuZCggdGhpcy5zdHlsZXNoZWV0ICk7XHJcblx0fVxyXG5cclxuXHR1cGRhdGVTdHlsZXNoZWV0KCkge1xyXG5cdFx0Y29uc3QgY3NzID0gdGhpcy5zZXR0aW5ncy5jc3MgPyBgJHtJbWFnZUNhcHRpb25QbHVnaW4uY2FwdGlvbl9zZWxlY3Rvcn0geyAke3RoaXMuc2V0dGluZ3MuY3NzfSB9YCA6ICcnO1xyXG5cclxuXHRcdGxldCBsYWJlbCA9IHRoaXMuc2V0dGluZ3MubGFiZWw7XHJcblx0XHRpZiAoIGxhYmVsICkge1xyXG5cdFx0XHQvLyByZXBsYWNlIGFsbCB1bmVzY2FwZWQgaGFzaHRhZ3Mgd2l0aCBpbWFnZSBpbmRleFxyXG5cdFx0XHRjb25zdCBudW1iZXJfcGF0dGVybiA9IC8oXnxbXlxcXFxdKSMvZztcclxuXHRcdFx0bGFiZWwgPSBsYWJlbC5yZXBsYWNlKCBudW1iZXJfcGF0dGVybiwgXCIkMScgYXR0cihkYXRhLWltYWdlLWNhcHRpb24taW5kZXgpICdcIiApOyAgLy8gaW5uZXIgcXVvdGVzIHVzZWQgdG8ga2lsbCBzdHJpbmcgYW5kIGluc2VydCBhdHRyLiArIGJldHdlZW4gc3RyaW5ncyBicmVha3MgaXQuXHJcblx0XHRcdFxyXG5cdFx0XHQvLyBSZXBsYWNlIGVzY2FwZWQgaGFzaHRhZ3Mgd2l0aCBoYXNodGFnc1xyXG5cdFx0XHRsYWJlbCA9IGxhYmVsLnJlcGxhY2UoICdcXFxcIycsICcjJyApO1xyXG5cclxuXHRcdFx0bGFiZWwgPSBgJHtJbWFnZUNhcHRpb25QbHVnaW4uY2FwdGlvbl9zZWxlY3Rvcn06OmJlZm9yZSB7IGNvbnRlbnQ6ICcke2xhYmVsfSAnIH1gOyAgLy8gYWRkaXRpb25hbCBzcGFjZSBpbiBjb250ZW50IGludGVudGlvbmFsXHJcblx0XHR9XHJcblxyXG5cdFx0dGhpcy5zdHlsZXNoZWV0LmlubmVyVGV4dCA9IGAke2Nzc30gJHtsYWJlbH1gO1xyXG5cdH1cclxuXHJcblx0cmVtb3ZlQ2FwdGlvbnMoKSB7XHJcblx0XHRmb3IgKCBjb25zdCBjYXB0aW9uIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoIEltYWdlQ2FwdGlvblBsdWdpbi5jYXB0aW9uX3NlbGVjdG9yICkgKSB7XHJcblx0XHRcdGNhcHRpb24ucmVtb3ZlKCk7XHJcblx0XHR9XHJcblx0fVxyXG59ICAvLyBlbmQgSW1hZ2VDYXB0aW9uUGx1Z2luXHJcblxyXG5cclxuY2xhc3MgSW1hZ2VDYXB0aW9uU2V0dGluZ1RhYiBleHRlbmRzIFBsdWdpblNldHRpbmdUYWIge1xyXG5cdHBsdWdpbjogSW1hZ2VDYXB0aW9uUGx1Z2luO1xyXG5cclxuXHRjb25zdHJ1Y3RvciggYXBwOiBBcHAsIHBsdWdpbjogSW1hZ2VDYXB0aW9uUGx1Z2luICkge1xyXG5cdFx0c3VwZXIoIGFwcCwgcGx1Z2luICk7XHJcblx0XHR0aGlzLnBsdWdpbiA9IHBsdWdpbjtcclxuXHR9XHJcblxyXG5cdGRpc3BsYXkoKTogdm9pZCB7XHJcblx0XHRsZXQgeyBjb250YWluZXJFbCB9ID0gdGhpcztcclxuXHRcdGNvbnRhaW5lckVsLmVtcHR5KCk7XHJcblxyXG5cdFx0bmV3IFNldHRpbmcoIGNvbnRhaW5lckVsIClcclxuXHRcdFx0LnNldE5hbWUoICdMYWJlbCcgKVxyXG5cdFx0XHQuc2V0RGVzYyggJ1ByZXBlbmQgdGhpcyB0ZXh0IGJlZm9yZSBlYWNoIGNhcHRpb24uJyApXHJcblx0XHRcdC5hZGRUZXh0KCAoIHRleHQgKSA9PiB0ZXh0XHJcblx0XHRcdFx0LnNldFBsYWNlaG9sZGVyKCAnTGFiZWwnIClcclxuXHRcdFx0XHQuc2V0VmFsdWUoIHRoaXMucGx1Z2luLnNldHRpbmdzLmxhYmVsIClcclxuXHRcdFx0XHQub25DaGFuZ2UoIGFzeW5jICggdmFsdWUgKSA9PiB7XHJcblx0XHRcdFx0XHR0aGlzLnBsdWdpbi5zZXR0aW5ncy5sYWJlbCA9IHZhbHVlLnRyaW0oKTtcclxuXHRcdFx0XHRcdGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xyXG5cdFx0XHRcdFx0dGhpcy5wbHVnaW4udXBkYXRlU3R5bGVzaGVldCgpO1xyXG5cdFx0XHRcdH0gKVxyXG5cdFx0XHQpO1xyXG5cclxuXHRcdG5ldyBTZXR0aW5nKCBjb250YWluZXJFbCApXHJcblx0XHRcdC5zZXROYW1lKCAnQ1NTJyApXHJcblx0XHRcdC5zZXREZXNjKCAnQ3VzdG9tIENTUyBzdHlsaW5nIGZvciBjYXB0aW9ucy4nIClcclxuXHRcdFx0LmFkZFRleHRBcmVhKCAoIHRleHQgKSA9PiB0ZXh0XHJcblx0XHRcdFx0LnNldFBsYWNlaG9sZGVyKCdFbnRlciB5b3VyIENTUycgKVxyXG5cdFx0XHRcdC5zZXRWYWx1ZSggdGhpcy5wbHVnaW4uc2V0dGluZ3MuY3NzIClcclxuXHRcdFx0XHQub25DaGFuZ2UoIGFzeW5jICggdmFsdWUgKSA9PiB7XHJcblx0XHRcdFx0XHR0aGlzLnBsdWdpbi5zZXR0aW5ncy5jc3MgPSB2YWx1ZS50cmltKCk7XHJcblx0XHRcdFx0XHRhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcclxuXHRcdFx0XHRcdHRoaXMucGx1Z2luLnVwZGF0ZVN0eWxlc2hlZXQoKTtcclxuXHRcdFx0XHR9IClcclxuXHRcdFx0KTtcclxuXHJcblx0XHQvLyBkZWxpbWV0ZXJcclxuXHRcdGNvbnN0IGRlbGltZXRlciA9IG5ldyBTZXR0aW5nKCBjb250YWluZXJFbCApXHJcblx0XHRcdC5zZXROYW1lKCAnRGVsaW1ldGVyJyApXHJcblx0XHRcdC5zZXREZXNjKFxyXG5cdFx0XHRcdCdJZGVudGlmeSB0aGUgY2FwdGlvbiBieSBzdXJyb3VuZGluZyBpdCB3aXRoIHRoZSBkZWxpbWV0ZXIuICcgK1xyXG5cdFx0XHRcdCdTdGFydCBhbmQgZW5kIGRlbGltZXRlcnMgbWF5cyBiZSBzcGVjaWZpZWQgYnkgc2VwYXJhdGlvbiB3aXRoIGEgY29tbWEgKCwpLidcclxuXHRcdFx0KVxyXG5cdFx0XHQuc2V0VG9vbHRpcChcclxuXHRcdFx0XHQnSWYgbm8gZGVsaW1ldGVyIGlzIHByb3ZpZGVkIHRoZSBlbnRpcmUgYWx0IHRleHQgaXMgdGFrZW4gdG8gYmUgdGhlIGNhcHRpb24uICcgK1xyXG5cdFx0XHRcdCdJZiBhIHNpbmdsZSBkZWxpbWV0ZXIgaXMgc3BlY2lmaWVkIGl0IG11c3QgaW5kaWNhdGUgdGhlIHN0YXJ0IGFuZCBlbmQgb2YgdGhlIGNhcHRpb24uICcgK1xyXG5cdFx0XHRcdCdJZiB0d28gZGVsaW1ldGVycyBhcmUgc3BlY2lmaWVkLCBieSBzZXBhcmF0aW9uIHdpdGggYSBjb21tYSwgdGhlIGNhcHRpb24gaXMgdGFrZW4gdG8gYmUgJyArXHJcblx0XHRcdFx0J3RoZSB0ZXh0IGJldHdlZW4gdGhlIHN0YXJ0IGFuZCBlbmQgZGVsaW1ldGVycy4nXHJcblx0XHRcdCk7XHJcblxyXG5cdFx0ZGVsaW1ldGVyLmFkZFRleHQoICggdGV4dCApID0+IHRleHRcclxuXHRcdFx0LnNldFBsYWNlaG9sZGVyKCAnRGVsaW1ldGVyJyApXHJcblx0XHRcdC5zZXRWYWx1ZSggdGhpcy5wbHVnaW4uc2V0dGluZ3MuZGVsaW1ldGVyLmpvaW4oICcsICcgKSApXHJcblx0XHRcdC5vbkNoYW5nZSggYXN5bmMgKCB2YWx1ZSApID0+IHtcclxuXHRcdFx0XHRsZXQgZGVsaW1ldGVycyA9IHZhbHVlLnNwbGl0KCAnLCcgKS5tYXAoIGQgPT4gZC50cmltKCkgKTtcclxuXHJcblx0XHRcdFx0Ly8gdmFsaWRhdGUgc2V0dGluZ1xyXG5cdFx0XHRcdGlmICggZGVsaW1ldGVycy5sZW5ndGggPiAyICkge1xyXG5cdFx0XHRcdFx0Ly8gdG9vIG1hbnkgZGVsaW1ldGVyc1xyXG5cdFx0XHRcdFx0ZGVsaW1ldGVyLmNvbnRyb2xFbC5hZGRDbGFzcyggJ3NldHRpbmctZXJyb3InICk7XHJcblx0XHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRpZiAoIGRlbGltZXRlcnMubGVuZ3RoID09PSAyICYmIGRlbGltZXRlcnMuc29tZSggZCA9PiAhZCApICkge1xyXG5cdFx0XHRcdFx0Ly8gZW1wdHkgZGVsaW1ldGVyXHJcblx0XHRcdFx0XHRkZWxpbWV0ZXIuY29udHJvbEVsLmFkZENsYXNzKCAnc2V0dGluZy1lcnJvcicgKTtcclxuXHRcdFx0XHRcdHJldHVybjtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdC8vIGRlbGltZXRlcnMgdmFsaWRcclxuXHRcdFx0XHRpZiAoIGRlbGltZXRlcnMubGVuZ3RoID09PSAxICYmIGRlbGltZXRlcnNbIDAgXSA9PT0gJycgKSB7XHJcblx0XHRcdFx0XHQvLyBubyBkZWxpbWV0ZXIgc3BlY2lmaWVkXHJcblx0XHRcdFx0XHRkZWxpbWV0ZXJzID0gW107XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRkZWxpbWV0ZXIuY29udHJvbEVsLnJlbW92ZUNsYXNzKCAnc2V0dGluZy1lcnJvcicgKTtcclxuXHRcdFx0XHR0aGlzLnBsdWdpbi5zZXR0aW5ncy5kZWxpbWV0ZXIgPSBkZWxpbWV0ZXJzO1xyXG5cdFx0XHRcdGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xyXG5cdFx0XHR9IClcclxuXHRcdCk7XHJcblx0fVxyXG59XHJcbiIsICJpbXBvcnQge1xyXG5cdFBsdWdpbixcclxuXHRNYXJrZG93blBvc3RQcm9jZXNzb3IsXHJcblx0TWFya2Rvd25Qb3N0UHJvY2Vzc29yQ29udGV4dCxcclxuXHRNYXJrZG93blJlbmRlckNoaWxkXHJcbn0gZnJvbSAnb2JzaWRpYW4nO1xyXG5cclxuaW1wb3J0IEltYWdlQ2FwdGlvblBsdWdpbiBmcm9tICcuL21haW4nO1xyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjYXB0aW9uT2JzZXJ2ZXIoIHBsdWdpbjogUGx1Z2luLCBjdHg6IE1hcmtkb3duUG9zdFByb2Nlc3NvckNvbnRleHQgKSB7XHJcblxyXG5cdHJldHVybiBuZXcgTXV0YXRpb25PYnNlcnZlciggKCBtdXRhdGlvbnMsIG9ic2VydmVyICkgPT4ge1xyXG5cdFx0Zm9yICggY29uc3QgbXV0YXRpb24gb2YgbXV0YXRpb25zICkge1xyXG5cdFx0XHRpZiAoICFtdXRhdGlvbi50YXJnZXQubWF0Y2hlcyggJ3NwYW4uaW1hZ2UtZW1iZWQnICkgKSB7XHJcblx0XHRcdFx0Y29udGludWU7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGxldCBjYXB0aW9uX3RleHQgPSBtdXRhdGlvbi50YXJnZXQuZ2V0QXR0cmlidXRlKCAnYWx0JyApO1xyXG5cdFx0XHRpZiAoIGNhcHRpb25fdGV4dCA9PT0gbXV0YXRpb24udGFyZ2V0LmdldEF0dHJpYnV0ZSggJ3NyYycgKSApIHtcclxuXHRcdFx0XHQvLyBkZWZhdWx0IGNhcHRpb24sIHNraXBcclxuXHRcdFx0XHRjb250aW51ZTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYgKCBtdXRhdGlvbi50YXJnZXQucXVlcnlTZWxlY3RvciggSW1hZ2VDYXB0aW9uUGx1Z2luLmNhcHRpb25fc2VsZWN0b3IgKSApIHtcclxuXHRcdFx0XHQvLyBjYXB0aW9uIGFscmVhZHkgYWRkZWRcclxuXHRcdFx0XHRjb250aW51ZTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Y2FwdGlvbl90ZXh0ID0gcGFyc2VDYXB0aW9uVGV4dCggY2FwdGlvbl90ZXh0LCBwbHVnaW4uc2V0dGluZ3MuZGVsaW1ldGVyICk7XHJcblx0XHRcdGlmICggY2FwdGlvbl90ZXh0ICE9PSBudWxsICkge1xyXG5cdFx0XHRcdGNvbnN0IGNhcHRpb24gPSBhZGRDYXB0aW9uKCBtdXRhdGlvbi50YXJnZXQsIGNhcHRpb25fdGV4dCApO1xyXG5cdFx0XHRcdGN0eC5hZGRDaGlsZCggY2FwdGlvbiApO1xyXG5cdFx0XHR9XHJcblx0XHR9ICAvLyBlbmQgZm9yLi5vZlxyXG5cclxuXHRcdHVwZGF0ZUZpZ3VyZUluZGljZXMoKTtcclxuXHRcdHBsdWdpbi5yZW1vdmVPYnNlcnZlciggb2JzZXJ2ZXIgKTtcclxuXHJcblx0fSApO1xyXG59XHJcblxyXG5cclxuZnVuY3Rpb24gcGFyc2VDYXB0aW9uVGV4dCggdGV4dDogc3RyaW5nLCBkZWxpbWV0ZXI6IHN0cmluZ1tdICk6IHN0cmluZyB8IG51bGwge1xyXG5cdGlmICggZGVsaW1ldGVyLmxlbmd0aCA9PT0gMCApIHtcclxuXHRcdHJldHVybiB0ZXh0O1xyXG5cdH1cclxuXHRcclxuXHRsZXQgc3RhcnQsIGVuZDtcclxuXHRpZiAoIGRlbGltZXRlci5sZW5ndGggPT0gMSApIHtcclxuXHRcdC8vIHNpbmdsZSBkZWxpbWV0ZXIgY2hhcmFjdGVyXHJcblx0XHRkZWxpbWV0ZXIgPSBkZWxpbWV0ZXJbIDAgXTtcclxuXHRcdHN0YXJ0ID0gdGV4dC5pbmRleE9mKCBkZWxpbWV0ZXIgKTtcclxuXHRcdGVuZCA9IHRleHQubGFzdEluZGV4T2YoIGRlbGltZXRlciApO1xyXG5cdH1cclxuXHRlbHNlIGlmICggZGVsaW1ldGVyLmxlbmd0aCA9PT0gMiApIHtcclxuXHRcdC8vIHNlcGFyYXRlIHN0YXJ0IGFuZCBlbmQgZGVsaW1ldGVyXHJcblx0XHRzdGFydCA9IHRleHQuaW5kZXhPZiggZGVsaW1ldGVyWyAwIF0gKTtcclxuXHRcdGVuZCA9IHRleHQubGFzdEluZGV4T2YoIGRlbGltZXRlclsgMSBdICk7XHJcblx0fVxyXG5cdGVsc2Uge1xyXG5cdFx0Ly8gZXJyb3JcclxuXHRcdHJldHVybiBudWxsO1xyXG5cdH1cclxuXHJcblx0aWYgKCBzdGFydCA9PT0gLTEgfHwgZW5kID09PSAtMSApIHtcclxuXHRcdHJldHVybiBudWxsO1xyXG5cdH1cclxuXHRpZiAoIHN0YXJ0ID09PSBlbmQgKSB7XHJcblx0XHRyZXR1cm4gJyc7XHJcblx0fVxyXG5cclxuXHRjb25zdCBzdGFydF9vZmZzZXQgPSBkZWxpbWV0ZXJbIDAgXS5sZW5ndGg7IC8vIGV4Y2x1ZGUgc3RhcnRpbmcgZGVsaW1ldGVyXHJcblx0cmV0dXJuIHRleHQuc2xpY2UoIHN0YXJ0ICsgc3RhcnRfb2Zmc2V0LCBlbmQgKTtcclxufSBcclxuXHJcblxyXG5mdW5jdGlvbiBhZGRDYXB0aW9uKFxyXG5cdHRhcmdldDogSFRNTEVsZW1lbnQsXHJcblx0Y2FwdGlvbl90ZXh0OiBzdHJpbmdcclxuKTogTWFya2Rvd25SZW5kZXJDaGlsZCB7XHJcblx0Y29uc3QgY2FwdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoIEltYWdlQ2FwdGlvblBsdWdpbi5jYXB0aW9uX3RhZyApO1xyXG5cdGNhcHRpb24uYWRkQ2xhc3MoIEltYWdlQ2FwdGlvblBsdWdpbi5jYXB0aW9uX2NsYXNzICk7XHJcblx0Y2FwdGlvbi5pbm5lclRleHQgPSBjYXB0aW9uX3RleHQ7XHJcblx0dGFyZ2V0LmFwcGVuZENoaWxkKCBjYXB0aW9uICk7XHJcblxyXG5cdHJldHVybiBuZXcgTWFya2Rvd25SZW5kZXJDaGlsZCggY2FwdGlvbiApO1xyXG59XHJcblxyXG5cclxuZnVuY3Rpb24gdXBkYXRlRmlndXJlSW5kaWNlcygpIHtcclxuXHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCAnZGl2LndvcmtzcGFjZS1sZWFmJyApLmZvckVhY2goXHJcblx0XHQoIGNvbnRhaW5lciA6IEhUTUxFbGVtZW50ICkgPT4ge1xyXG5cdFx0XHRsZXQgaW5kZXggPSAxO1xyXG5cdFx0XHRjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCggSW1hZ2VDYXB0aW9uUGx1Z2luLmNhcHRpb25fc2VsZWN0b3IgKS5mb3JFYWNoKFxyXG5cdFx0XHRcdCggZWw6IEhUTUxFbGVtZW50ICkgPT4ge1xyXG5cdFx0XHRcdFx0ZWwuZGF0YXNldC5pbWFnZUNhcHRpb25JbmRleCA9IGluZGV4O1xyXG5cdFx0XHRcdFx0aW5kZXggKz0gMTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdCk7XHJcblx0XHR9XHJcblx0KTtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBwcm9jZXNzSW1hZ2VDYXB0aW9uKFxyXG5cdHBsdWdpbjogUGx1Z2luXHJcbik6ICggZWw6IEhUTUxFbGVtZW50LCBjdHg6IE1hcmtkb3duUG9zdFByb2Nlc3NvckNvbnRleHQgKSA9PiB2b2lkIHtcclxuXHJcblx0cmV0dXJuIGZ1bmN0aW9uIChcclxuXHRcdGVsOiBIVE1MRWxlbWVudCxcclxuXHRcdGN0eDogTWFya2Rvd25Qb3N0UHJvY2Vzc29yQ29udGV4dFxyXG5cdCk6IHZvaWQge1xyXG5cdFx0ZWwucXVlcnlTZWxlY3RvckFsbCggJ3NwYW4uaW50ZXJuYWwtZW1iZWQnICkuZm9yRWFjaChcclxuXHRcdFx0KCBjb250YWluZXI6IEhUTUxFbGVtZW50ICkgPT4ge1xyXG5cdFx0XHRcdC8vIG11c3QgbGlzdGVuIGZvciBjbGFzcyBjaGFuZ2VzIGJlY2F1c2UgaW1hZ2VzXHJcblx0XHRcdFx0Ly8gbWF5IGJlIGxvYWRlZCBhZnRlciB0aGlzIHJ1blxyXG5cdFx0XHRcdGNvbnN0IG9ic2VydmVyID0gY2FwdGlvbk9ic2VydmVyKCBwbHVnaW4sIGN0eCApO1xyXG5cdFx0XHRcdG9ic2VydmVyLm9ic2VydmUoXHJcblx0XHRcdFx0XHRjb250YWluZXIsXHJcblx0XHRcdFx0XHR7IGF0dHJpYnV0ZXM6IHRydWUsIGF0dHJpYnV0ZXNGaWx0ZXI6IFsgJ2NsYXNzJyBdIH1cclxuXHRcdFx0XHQpO1xyXG5cclxuXHRcdFx0XHRwbHVnaW4uYWRkT2JzZXJ2ZXIoIG9ic2VydmVyICk7XHJcblx0XHRcdH1cclxuXHRcdCk7XHJcblx0fTtcclxufSJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtPOzs7QUNMUCxzQkFLTztBQUtBLHlCQUEwQixRQUFnQixLQUFvQztBQUVwRixTQUFPLElBQUksaUJBQWtCLENBQUUsV0FBVyxhQUFjO0FBQ3ZELGVBQVksWUFBWSxXQUFZO0FBQ25DLFVBQUssQ0FBQyxTQUFTLE9BQU8sUUFBUyxxQkFBdUI7QUFDckQ7QUFBQTtBQUdELFVBQUksZUFBZSxTQUFTLE9BQU8sYUFBYztBQUNqRCxVQUFLLGlCQUFpQixTQUFTLE9BQU8sYUFBYyxRQUFVO0FBRTdEO0FBQUE7QUFHRCxVQUFLLFNBQVMsT0FBTyxjQUFlLG1CQUFtQixtQkFBcUI7QUFFM0U7QUFBQTtBQUdELHFCQUFlLGlCQUFrQixjQUFjLE9BQU8sU0FBUztBQUMvRCxVQUFLLGlCQUFpQixNQUFPO0FBQzVCLGNBQU0sVUFBVSxXQUFZLFNBQVMsUUFBUTtBQUM3QyxZQUFJLFNBQVU7QUFBQTtBQUFBO0FBSWhCO0FBQ0EsV0FBTyxlQUFnQjtBQUFBO0FBQUE7QUFNekIsMEJBQTJCLE1BQWMsV0FBcUM7QUFDN0UsTUFBSyxVQUFVLFdBQVcsR0FBSTtBQUM3QixXQUFPO0FBQUE7QUFHUixNQUFJLE9BQU87QUFDWCxNQUFLLFVBQVUsVUFBVSxHQUFJO0FBRTVCLGdCQUFZLFVBQVc7QUFDdkIsWUFBUSxLQUFLLFFBQVM7QUFDdEIsVUFBTSxLQUFLLFlBQWE7QUFBQSxhQUVmLFVBQVUsV0FBVyxHQUFJO0FBRWxDLFlBQVEsS0FBSyxRQUFTLFVBQVc7QUFDakMsVUFBTSxLQUFLLFlBQWEsVUFBVztBQUFBLFNBRS9CO0FBRUosV0FBTztBQUFBO0FBR1IsTUFBSyxVQUFVLE1BQU0sUUFBUSxJQUFLO0FBQ2pDLFdBQU87QUFBQTtBQUVSLE1BQUssVUFBVSxLQUFNO0FBQ3BCLFdBQU87QUFBQTtBQUdSLFFBQU0sZUFBZSxVQUFXLEdBQUk7QUFDcEMsU0FBTyxLQUFLLE1BQU8sUUFBUSxjQUFjO0FBQUE7QUFJMUMsb0JBQ0MsUUFDQSxjQUNzQjtBQUN0QixRQUFNLFVBQVUsU0FBUyxjQUFlLG1CQUFtQjtBQUMzRCxVQUFRLFNBQVUsbUJBQW1CO0FBQ3JDLFVBQVEsWUFBWTtBQUNwQixTQUFPLFlBQWE7QUFFcEIsU0FBTyxJQUFJLG9DQUFxQjtBQUFBO0FBSWpDLCtCQUErQjtBQUM5QixXQUFTLGlCQUFrQixzQkFBdUIsUUFDakQsQ0FBRSxjQUE2QjtBQUM5QixRQUFJLFFBQVE7QUFDWixjQUFVLGlCQUFrQixtQkFBbUIsa0JBQW1CLFFBQ2pFLENBQUUsT0FBcUI7QUFDdEIsU0FBRyxRQUFRLG9CQUFvQjtBQUMvQixlQUFTO0FBQUE7QUFBQTtBQUFBO0FBUVAsNkJBQ04sUUFDaUU7QUFFakUsU0FBTyxTQUNOLElBQ0EsS0FDTztBQUNQLE9BQUcsaUJBQWtCLHVCQUF3QixRQUM1QyxDQUFFLGNBQTRCO0FBRzdCLFlBQU0sV0FBVyxnQkFBaUIsUUFBUTtBQUMxQyxlQUFTLFFBQ1IsV0FDQSxFQUFFLFlBQVksTUFBTSxrQkFBa0IsQ0FBRTtBQUd6QyxhQUFPLFlBQWE7QUFBQTtBQUFBO0FBQUE7OztBRHhHeEIsSUFBTSxtQkFBeUM7QUFBQSxFQUM5QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUE7QUFJWix3Q0FBZ0Qsd0JBQU87QUFBQSxFQVFoRCxTQUFTO0FBQUE7QUFDZCxZQUFNLEtBQUs7QUFFWCxXQUFLLG9CQUFvQjtBQUN6QixXQUFLLDhCQUErQixvQkFBcUI7QUFFekQsV0FBSztBQUNMLFdBQUssY0FBZSxJQUFJLHVCQUF3QixLQUFLLEtBQUs7QUFBQTtBQUFBO0FBQUEsRUFHM0QsV0FBVztBQUNWLFNBQUssV0FBVztBQUNoQixTQUFLO0FBQ0wsU0FBSztBQUFBO0FBQUEsRUFHQSxlQUFlO0FBQUE7QUFDcEIsV0FBSyxXQUFXLE9BQU8sT0FBUSxJQUFJLGtCQUFrQixNQUFNLEtBQUs7QUFBQTtBQUFBO0FBQUEsRUFHM0QsZUFBZTtBQUFBO0FBQ3BCLFlBQU0sS0FBSyxTQUFVLEtBQUs7QUFBQTtBQUFBO0FBQUEsRUFHM0IsWUFBYSxVQUE2QjtBQUN6QyxTQUFLLGtCQUFrQixLQUFNO0FBQUE7QUFBQSxFQUc5QixlQUFnQixVQUE2QjtBQUM1QyxhQUFTO0FBQ1QsVUFBTSxRQUFRLEtBQUssa0JBQWtCLFFBQVM7QUFDOUMsU0FBSyxrQkFBa0IsT0FBUSxPQUFPO0FBQUE7QUFBQSxFQUd2QyxpQkFBaUI7QUFDaEIsZUFBWSxZQUFZLEtBQUssbUJBQW9CO0FBQ2hELGVBQVM7QUFBQTtBQUdWLFNBQUssb0JBQW9CO0FBQUE7QUFBQSxFQUcxQixnQkFBZ0I7QUFDZixTQUFLLGFBQWEsU0FBUyxjQUFlO0FBQzFDLFNBQUssV0FBVyxhQUFjLFFBQVE7QUFDdEMsU0FBSztBQUNMLGFBQVMsS0FBSyxPQUFRLEtBQUs7QUFBQTtBQUFBLEVBRzVCLG1CQUFtQjtBQUNsQixVQUFNLE1BQU0sS0FBSyxTQUFTLE1BQU0sR0FBRyxvQkFBbUIsc0JBQXNCLEtBQUssU0FBUyxVQUFVO0FBRXBHLFFBQUksUUFBUSxLQUFLLFNBQVM7QUFDMUIsUUFBSyxPQUFRO0FBRVosWUFBTSxpQkFBaUI7QUFDdkIsY0FBUSxNQUFNLFFBQVMsZ0JBQWdCO0FBR3ZDLGNBQVEsTUFBTSxRQUFTLE9BQU87QUFFOUIsY0FBUSxHQUFHLG9CQUFtQix3Q0FBd0M7QUFBQTtBQUd2RSxTQUFLLFdBQVcsWUFBWSxHQUFHLE9BQU87QUFBQTtBQUFBLEVBR3ZDLGlCQUFpQjtBQUNoQixlQUFZLFdBQVcsU0FBUyxpQkFBa0Isb0JBQW1CLG1CQUFxQjtBQUN6RixjQUFRO0FBQUE7QUFBQTtBQUFBO0FBN0VYO0FBR1EsQUFIUixtQkFHUSxjQUFzQjtBQUN0QixBQUpSLG1CQUlRLGdCQUF3QjtBQUN4QixBQUxSLG1CQUtRLG1CQUEyQixHQUFHLG9CQUFtQixlQUFlLG9CQUFtQjtBQThFM0YsMkNBQXFDLGtDQUFpQjtBQUFBLEVBR3JELFlBQWEsS0FBVSxRQUE2QjtBQUNuRCxVQUFPLEtBQUs7QUFDWixTQUFLLFNBQVM7QUFBQTtBQUFBLEVBR2YsVUFBZ0I7QUFDZixRQUFJLEVBQUUsZ0JBQWdCO0FBQ3RCLGdCQUFZO0FBRVosUUFBSSx5QkFBUyxhQUNYLFFBQVMsU0FDVCxRQUFTLDBDQUNULFFBQVMsQ0FBRSxTQUFVLEtBQ3BCLGVBQWdCLFNBQ2hCLFNBQVUsS0FBSyxPQUFPLFNBQVMsT0FDL0IsU0FBVSxDQUFRLFVBQVc7QUFDN0IsV0FBSyxPQUFPLFNBQVMsUUFBUSxNQUFNO0FBQ25DLFlBQU0sS0FBSyxPQUFPO0FBQ2xCLFdBQUssT0FBTztBQUFBO0FBSWYsUUFBSSx5QkFBUyxhQUNYLFFBQVMsT0FDVCxRQUFTLG9DQUNULFlBQWEsQ0FBRSxTQUFVLEtBQ3hCLGVBQWUsa0JBQ2YsU0FBVSxLQUFLLE9BQU8sU0FBUyxLQUMvQixTQUFVLENBQVEsVUFBVztBQUM3QixXQUFLLE9BQU8sU0FBUyxNQUFNLE1BQU07QUFDakMsWUFBTSxLQUFLLE9BQU87QUFDbEIsV0FBSyxPQUFPO0FBQUE7QUFLZixVQUFNLFlBQVksSUFBSSx5QkFBUyxhQUM3QixRQUFTLGFBQ1QsUUFDQSx5SUFHQSxXQUNBO0FBTUYsY0FBVSxRQUFTLENBQUUsU0FBVSxLQUM3QixlQUFnQixhQUNoQixTQUFVLEtBQUssT0FBTyxTQUFTLFVBQVUsS0FBTSxPQUMvQyxTQUFVLENBQVEsVUFBVztBQUM3QixVQUFJLGFBQWEsTUFBTSxNQUFPLEtBQU0sSUFBSyxPQUFLLEVBQUU7QUFHaEQsVUFBSyxXQUFXLFNBQVMsR0FBSTtBQUU1QixrQkFBVSxVQUFVLFNBQVU7QUFDOUI7QUFBQTtBQUdELFVBQUssV0FBVyxXQUFXLEtBQUssV0FBVyxLQUFNLE9BQUssQ0FBQyxJQUFNO0FBRTVELGtCQUFVLFVBQVUsU0FBVTtBQUM5QjtBQUFBO0FBSUQsVUFBSyxXQUFXLFdBQVcsS0FBSyxXQUFZLE9BQVEsSUFBSztBQUV4RCxxQkFBYTtBQUFBO0FBR2QsZ0JBQVUsVUFBVSxZQUFhO0FBQ2pDLFdBQUssT0FBTyxTQUFTLFlBQVk7QUFDakMsWUFBTSxLQUFLLE9BQU87QUFBQTtBQUFBO0FBQUE7IiwKICAibmFtZXMiOiBbXQp9Cg==
