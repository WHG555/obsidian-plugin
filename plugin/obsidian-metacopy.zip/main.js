var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// src/main.ts
__export(exports, {
  copy: () => copy,
  default: () => MetaCopy,
  getValue: () => getValue
});
var import_obsidian3 = __toModule(require("obsidian"));

// src/settings.ts
var import_obsidian = __toModule(require("obsidian"));
var DEFAULT_SETTINGS = {
  link: ""
};
var CopySettingsTabs = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    let { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Metacopy Settings" });
    new import_obsidian.Setting(containerEl).setName("Key").setDesc("The key which you want to copy the value").addTextArea((text) => text.setPlaceholder("key1, key2, key3,\u2026").setValue(this.plugin.settings.link).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.link = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// src/modal.ts
var import_obsidian2 = __toModule(require("obsidian"));
function get_all_meta(app, file, settings) {
  let meta_value = [];
  const frontmatter = app.metadataCache.getCache(file.path).frontmatter;
  const key_meta = settings.link;
  let list_key = key_meta.split(",");
  list_key = list_key.map((x) => x.trim());
  if (list_key.length > 0) {
    for (let i = 0; i < list_key.length; i++) {
      meta_value.push(frontmatter[list_key[i].trim()]);
    }
  }
  const interfaced = list_key.map((key, i) => ({ key, value: meta_value[i] }));
  return interfaced;
}
var CopyMetaSuggester = class extends import_obsidian2.FuzzySuggestModal {
  constructor(app, settings, file) {
    super(app);
    this.file = file;
    this.settings = settings;
  }
  getItemText(item) {
    return item.key;
  }
  getItems() {
    const interfaced = get_all_meta(this.app, this.file, this.settings);
    return interfaced;
  }
  onChooseItem(item, evt) {
    item.value = item.value.toString();
    if (item.value.split(",").length > 1) {
      item.value = "- " + item.value.replaceAll(",", "\n- ");
    }
    copy(item.value, item.key);
  }
};

// src/main.ts
function copy(content, item) {
  return __async(this, null, function* () {
    yield navigator.clipboard.writeText(content);
    new import_obsidian3.Notice("Metadata " + item + " copied to clipboard");
  });
}
function getMeta(app, file, settings) {
  const fileCache = app.metadataCache.getFileCache(file);
  const meta = fileCache == null ? void 0 : fileCache.frontmatter;
  if (meta === void 0) {
    return ["", ""];
  }
  let link_value = "";
  let meta_key = "";
  if (settings) {
    const key_meta = settings.link.replace(" ", ",");
    const list_key = key_meta.split(",");
    meta_key = key_meta;
    if (list_key.length > 1) {
      for (let i = 0; i < list_key.length; i++) {
        if (meta[list_key[i]] !== void 0) {
          link_value = meta[list_key[i]];
          meta_key = list_key[i];
          break;
        }
      }
    } else {
      {
        link_value = meta[list_key[0]];
        meta_key = list_key[0];
      }
    }
  }
  return [link_value, meta_key];
}
function checkMeta(app, settings) {
  const file = app.workspace.getActiveFile();
  const meta = getMeta(app, file, settings)[0];
  return !!file && !!meta;
}
function getValue(app, file, settings) {
  return __async(this, null, function* () {
    const meta = getMeta(app, file, settings);
    if (!meta) {
      return false;
    }
    meta[0] = meta[0].toString();
    if (meta[0].split(",").length > 1) {
      meta[0] = "- " + meta[0].replaceAll(",", "\n- ");
    }
    yield copy(meta[0], meta[1]);
  });
}
var MetaCopy = class extends import_obsidian3.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("MetaCopy loaded");
      yield this.loadSettings();
      this.addSettingTab(new CopySettingsTabs(this.app, this));
      this.registerEvent(this.app.workspace.on("file-menu", (menu, file) => {
        const meta = getMeta(this.app, file, this.settings);
        console.log(meta);
        if (!meta) {
          return false;
        }
        const key_meta = meta[1];
        if (meta[0]) {
          menu.addSeparator();
          menu.addItem((item) => {
            item.setTitle("Copy [" + key_meta + "]").setIcon("two-blank-pages").onClick(() => __async(this, null, function* () {
              yield getValue(this.app, file, this.settings);
            }));
          });
          menu.addSeparator();
        }
      }));
      this.addCommand({
        id: "obsidian-metacopy",
        name: "Metacopy",
        hotkeys: [],
        checkCallback: (checking) => {
          let fileMeta = checkMeta(this.app, this.settings);
          if (fileMeta) {
            if (!checking) {
              new CopyMetaSuggester(this.app, this.settings, this.app.workspace.getActiveFile()).open();
            }
            return true;
          }
          return false;
        }
      });
    });
  }
  onunload() {
    return __async(this, null, function* () {
      console.log("MetaCopy unloaded");
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
